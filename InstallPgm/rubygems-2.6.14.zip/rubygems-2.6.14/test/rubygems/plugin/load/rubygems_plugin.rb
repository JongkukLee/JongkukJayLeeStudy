# frozen_string_literal: true
class TestGem
  TEST_PLUGIN_LOAD = :loaded
end
