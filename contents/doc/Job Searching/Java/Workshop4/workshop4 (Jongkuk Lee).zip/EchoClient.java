/**********************************************
 Course:JAC444 - 4
 Last Name: Lee
 First Name: Jongkuk
 ID: 127730158
 Section: SCC
 This assignment represents my own work in accordance with
 Seneca Academic Policy.
 Signature JK Lee
 Date: 2017-12-21
**********************************************/
package ca.jay.jac444.workshop4;

import java.io.*;
import java.net.*;
import java.util.Scanner;

// This class is designed for chat client application using socket
public class EchoClient {

	// write the test program
	public static void main(String[] args) throws Exception
	{
		try {		
	    	// check if the command line arguments exist
	    	if(args != null && args.length == 0)
				throw new Workshop4Exception(W4TaskIF.ERR15_MSG);		
		}
		catch(Workshop4Exception we)
		{
    		System.out.println(we.getMessage());
    		System.exit(-1);
		}		
		// Prompt the user to enter a guess
		System.out.print("Enter you name: ");
		Scanner input = new Scanner(System.in);
		String nickname = input.next();
					
		InetAddress addr = InetAddress.getLocalHost();
		String hostName = addr.getHostName();
		int portNumber = Integer.parseInt(args[0]);

		try (
		
			Socket echoSocket = new Socket(hostName, portNumber);
			PrintWriter out = new PrintWriter(echoSocket.getOutputStream(), true);
			BufferedReader in = 
					new BufferedReader(new InputStreamReader(echoSocket.getInputStream()));
			BufferedReader stdIn = 
					new BufferedReader(new InputStreamReader(System.in));
		)
		{
			String str="";  
			while(str != null && !str.equals("stop"))
			{ 
				//System.out.println("test=[" + str + "]");
				System.out.print("Enter Text: "); 
				str=stdIn.readLine();
				out.println(nickname + W4TaskIF.DELIMITE_CHAT + str);
			} 			
		}
		catch(IOException e)
		{
    		System.out.println(W4TaskIF.ERR16_MSG);
		}		
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(input != null) input.close();
		}
	}
}
