/**********************************************
 Course:JAC444 - 4
 Last Name: Lee
 First Name: Jongkuk
 ID: 127730158
 Section: SCC
 This assignment represents my own work in accordance with
 Seneca Academic Policy.
 Signature JK Lee
 Date: 2017-12-21
**********************************************/
package ca.jay.jac444.workshop4;

// This class defines the functions to play Workshop3 
public class W4TaskUtil implements W4TaskIF
{
	// validate Number of banks
	public static int validNumberOfBank(String s) throws Exception
	{
		try
		{
			if (s.isEmpty())
				throw new Workshop4Exception(W4TaskIF.ERR4_MSG);
			
			if (new Integer(s) < 0)
				throw new Workshop4Exception(W4TaskIF.ERR10_MSG);
			
			return new Integer(s);			
		}
		catch(NumberFormatException e)
		{
			throw new Workshop4Exception(W4TaskIF.ERR8_MSG + ": " + s);
		}
	}

	// validate the limit asset
	public static double validLimitAsset(String s) throws Exception
	{
		try
		{
			if (s.isEmpty())
				throw new Workshop4Exception(W4TaskIF.ERR5_MSG);			
			
			if (new Integer(s) < 0)
				throw new Workshop4Exception(W4TaskIF.ERR10_MSG);
			
			//if (new Double(s) < 0.0d)
			//	throw new Workshop4Exception(W4TaskIF.ERR10_MSG);
			
			return new Double(s);			
		}
		catch(NumberFormatException e)
		{
			throw new Workshop4Exception(W4TaskIF.ERR8_MSG + ": " + s);
		}
	}

	// validate the BankInformation
	public static void validBankRow(int bankId, String s, String d) throws Exception
	{
		try
		{
			if (s.isEmpty())
				throw new Workshop4Exception(W4TaskIF.ERR6_MSG);
			
			String[] bank = s.split(d);
			if(bank.length < 2)
				throw new Workshop4Exception(W4TaskIF.ERR11_MSG + ": bank id: " + bankId + ", bank info row: [" + s + "]" + " or " + 
			                                 W4TaskIF.ERR17_MSG + ": " + d);			
			
			// check if the value is empty
			for(String e: bank)
				if(e.isEmpty())
					throw new Workshop4Exception(W4TaskIF.ERR19_MSG + ": bank id: " + bankId + ", bank info row: [" + s + "]");					
			
			// check if the value is digit or not 
			for(String e: bank)
				for(int i = 0; i < e.length(); i++)
					if(e.charAt(i) != '.' && !Character.isDigit(e.charAt(i)))
						throw new Workshop4Exception(W4TaskIF.ERR13_MSG + ": " + e);	
			
			// With compared between bank id and borrower id, if the same, error
			// if loan money is 0, error 
			for(int i = 2; i < bank.length; i+=2)
			{
				if(bankId == new Integer(bank[i])) 
					throw new Workshop4Exception(W4TaskIF.ERR14_MSG + ": bank id: " + bankId + ", bank info row: [" + s + "]");
				if(new Double(bank[i+1]) == 0.0d) 
					throw new Workshop4Exception(W4TaskIF.ERR18_MSG + ": bank id: " + bankId + ", bank info row: [" + s + "]");				
			}
		}
		catch(NumberFormatException e)
		{
			throw new Workshop4Exception(W4TaskIF.ERR13_MSG + ": " + s);
		}
	}
	
	// check matching between the number of bank of file and actual the number of bank
	public static void validNumberMatch(int n1, int n2) throws Exception
	{
		if(n1 != n2) 
			throw new Workshop4Exception(W4TaskIF.ERR7_MSG + ": " + n1 + ", " + n2);
	}
}