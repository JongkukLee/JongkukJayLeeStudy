/**********************************************
 Course:JAC444 - 4
 Last Name: Lee
 First Name: Jongkuk
 ID: 127730158
 Section: SCC
 This assignment represents my own work in accordance with
 Seneca Academic Policy.
 Signature JK Lee
 Date: 2017-12-21
**********************************************/
package ca.jay.jac444.workshop4;

public interface W4TaskIF 
{
	public static final String DELIMITE_CHAT = "$%^&*";
	
	public static final String ERR1_MSG = "It needs a command-line arguments for a file name";
	public static final String ERR2_MSG = "It cannot find the file";	
	public static final String ERR3_MSG = "The input file is not .java file.";
	
	public static final String ERR4_MSG = "In file, the value of the nubmer of bank cannot be empty";	
	public static final String ERR5_MSG = "In file, the value of the limit asset cannot be empty";	
	public static final String ERR6_MSG = "In file, the value of the bank information cannot be empty";	
	public static final String ERR7_MSG = "In file, there is not matched between the number of bank of file and actual the number of bank";	
	public static final String ERR8_MSG = "In file, the value must be an integer";	
	public static final String ERR9_MSG = "In file, the value must be a double";	
	public static final String ERR10_MSG= "In file, the value cannot be a negative";
	public static final String ERR11_MSG= "In file, the number of elements of bank line must be at least two";	
	public static final String ERR12_MSG= "It needs a command-line arguments for a file name and delimiter";	
	public static final String ERR13_MSG= "In file, the value must be a double or an integer";    
	public static final String ERR14_MSG= "In file, bank id and borrower id cannot be the same";
	
	public static final String ERR15_MSG= "It needs a command-line arguments for a port";	
	public static final String ERR16_MSG= "The connection is failed. Please check your environment ex) host, port etc";

	public static final String ERR17_MSG= "Check your delimiter";
	public static final String ERR18_MSG= "The loan money cannot be 0";	
	public static final String ERR19_MSG = "In file, the value cannot be empty";	
	// Array of all Java keywords + true, false and null
    public String[] keywordString = {
    		"abstract",	"assert",	 	"boolean",	"break",
    		"byte",		"case",		 	"catch",	"char",
    		"class",	"const",	 	"continue",	"default",
    		"do",		"double",	 	"else",		"enum",
    		"extends",	"final",	 	"finally",	"float",
    		"for",		"goto",		 	"if",		"implements",
    		"import",	"instanceof",	"int",		"interface",
    		"long",		"native",	 	"new",		"package",
    		"private",	"protected", 	"public",	"return",
    		"short",	"static",	 	"strictfp",	"super",
    		"switch",	"synchronized",	"this",		"throw",
    		"throws",	"transient",	"try",		"void",
    		"volatile",	"while",		"true",		"false",
    		"null"
    };
}
