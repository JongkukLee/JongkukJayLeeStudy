/**********************************************
 Course:JAC444 - 4
 Last Name: Lee
 First Name: Jongkuk
 ID: 127730158
 Section: SCC
 This assignment represents my own work in accordance with
 Seneca Academic Policy.
 Signature JK Lee
 Date: 2017-12-21
**********************************************/
package ca.jay.jac444.workshop4;

import java.net.*;
import java.util.Date;
import java.io.*;

// This class is designed a chat server using socket
public class EchoServer {

	// write the test program
	public static void main(String[] args) throws Exception
	{
		// open socket
		ServerSocket serverSocket = null;		
		try
		{
	    	// check if the command line arguments exist
	    	if(args != null && args.length == 0)
				throw new Workshop4Exception(W4TaskIF.ERR15_MSG);
			
			int portNumber = Integer.parseInt(args[0]);
			// open socket
			serverSocket = 
					new ServerSocket(portNumber);
	
			// display open the server
			System.out.println("MultiThreadServer started at " + new Date().toString() + "\n");
			
			// wait for that client attempt to connect
			ClientWorker cworker; // do actual action in this object
			while(true)
			{
				// server.accept returns a client connection
				cworker = new ClientWorker(serverSocket.accept());
				Thread t = new Thread(cworker);
				t.start();
			}
    	}
    	catch(Workshop4Exception we)
    	{
    		System.out.println(we.getMessage());
    	}
		catch(IOException e)
		{
			throw new Exception(W4TaskIF.ERR16_MSG);
		}		
		catch(Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
	}

}
