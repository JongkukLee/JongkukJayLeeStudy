/**********************************************
 Course:JAC444 - 4
 Last Name: Lee
 First Name: Jongkuk
 ID: 127730158
 Section: SCC
 This assignment represents my own work in accordance with
 Seneca Academic Policy.
 Signature JK Lee
 Date: 2017-12-21
**********************************************/
package ca.jay.jac444.workshop4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

//This class implements to count the java keywords in java file
public class W4Task1 implements W4TaskIF {

    private static boolean[] states = new boolean[4];
    private static final int BLOCK = 0;
    private static final int LINE = 1;
    private static final int STRING = 2;	
	
    public static void main(String[] args) throws Exception 
    {
    	try
    	{
	    	// check if the command line arguments exist
	    	if(args != null && args.length == 0)
				throw new Workshop4Exception(W4TaskIF.ERR1_MSG);
			
	    	String filename = args[0];
	    	// if not java file, error occurs
	    	if(filename != null && filename.indexOf(".java") == -1)
				throw new Workshop4Exception(W4TaskIF.ERR3_MSG);    		
	    	
	        File file = new File(filename);
	        if (file.exists()) {
	            System.out.println("The number of keywords in " + file.getName()
	                    + " is " + countKeywords(file));
	        } else {
	        	// cannot find file
				throw new FileNotFoundException(W4TaskIF.ERR2_MSG);
	        }
    	}
    	catch(Workshop4Exception we)
    	{
    		System.out.println(we.getMessage());
    	}
    	catch(FileNotFoundException fe)
    	{
    		System.out.println(fe.getMessage());
    		//fe.printStackTrace();
    	}
    	catch(Exception e)
    	{
    		System.out.println(e.getMessage());
    		e.printStackTrace();
    	}
    }

    // count the number of keyword from the file and return it
    public static int countKeywords(File file) throws Exception 
    {
        Scanner input = new Scanner(file);

        // get the Java keywords and store them to Set collection
        Set<String> keywords = new HashSet<>(Arrays.asList(W4TaskIF.keywordString));
        
        // concatnate all words in the file
        String word = "";
        while (input.hasNext()) {
            word += input.nextLine() + "\n";
        }

        int index;
        // According to comment types (/*, //, \"), remove the comment part
        while ((index = getNextState(word)) != -1) {
            if (states[BLOCK])
                word = removeBlock(word, index);
            else if (states[LINE])
                word = removeLine(word, index);
            else if (states[STRING])
                word = removeString(word, index);
        }
		List<String> words = Arrays.asList(word.split("\\W"));

        input.close();		
		return (int)words.stream()
		.filter(s -> s.length() > 0 && keywords.contains(s)).count();
    }

    // remove string quote
    private static String removeString(String word, int index) {

        states[STRING] = false;
        String clean = word.substring(0, index);
        String dirty = word.substring(index + 1);
        int dQuote = dirty.indexOf("\"");
        
        return clean + dirty.substring(dQuote + 1);
    }

    // remove in-line comment part
    private static String removeLine(String word, int index) 
    {
        states[LINE] = false;
        String clean = word.substring(0, index);
        String end = word.substring(index);
        end = end.substring(end.indexOf("\n"));

        return clean + end;
    }

    // remove a block-comment part
    private static String removeBlock(String s, int index) 
    {
        states[BLOCK] = false;
        int end = s.indexOf("*/");
        String clean = s.substring(0, index);
        String endString = s.substring(end + 2);

        return clean + endString;
    }

    // find the next comment type and position and return it
    public static int getNextState(String s) 
    {

        int[] indices = new int[3];
        String[] startStateTokens = {"/*", "//", "\""};        
        int lowest = 99999999;
        int key = 0;
        for (int i = 0; i < indices.length; i++) {
            indices[i] = s.indexOf(startStateTokens[i]);
            if (lowest > indices[i] && indices[i] >= 0) {
                lowest = indices[i];
                key = i;
            }
        }        
        if (key != -1) states[key] = true;

        return indices[key];
    }
}
