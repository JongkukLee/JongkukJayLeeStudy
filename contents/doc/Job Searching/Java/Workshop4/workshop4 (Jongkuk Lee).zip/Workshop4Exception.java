/**********************************************
 Course:JAC444 - 4
 Last Name: Lee
 First Name: Jongkuk
 ID: 127730158
 Section: SCC
 This assignment represents my own work in accordance with
 Seneca Academic Policy.
 Signature JK Lee
 Date: 2017-12-21
**********************************************/
package ca.jay.jac444.workshop4;

public class Workshop4Exception extends Exception {
	
	// default constructor
	Workshop4Exception()
	{
		super();
	}
	
	// constructor that receive message:String parameter
	Workshop4Exception(String message)
	{
		super(message);
	}
}