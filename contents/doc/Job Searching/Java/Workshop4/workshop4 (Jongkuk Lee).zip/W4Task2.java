/**********************************************
 Course:JAC444 - 4
 Last Name: Lee
 First Name: Jongkuk
 ID: 127730158
 Section: SCC
 This assignment represents my own work in accordance with
 Seneca Academic Policy.
 Signature JK Lee
 Date: 2017-12-21
**********************************************/
package ca.jay.jac444.workshop4;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

// This class is designed the loan information of bank 
class Loan {
	private int loanBankId = -1;
	private double loanAmount = -1.0d;
	
	// constructor
	Loan(int id, double loan )
	{
		this.loanBankId = id;
		this.loanAmount = loan;
	}

	// getter
	public int getLoanBankId()
	{
		return this.loanBankId;
	}
	public double getLoanAmount()
	{
		return this.loanAmount;
	}	
}

// This class is designed the bank
class Bank {
	
	private int bankId = -1;
	private double bankBalance = -1.0d;
	private int numberOfLoan = -1;
	private List<Loan> loans = null;
	private double totalAsset = -1.0;
	
	// constructor
	Bank(int id, double balance, int loanNumber, List<Loan> loans)
	{
		this.loans = loans;		
		this.bankId = id;
		this.bankBalance = balance;
		this.numberOfLoan = loanNumber;
		this.setTotalAsset();
	}
	// set total asset
	public void setTotalAsset()
	{
		double sumLoan = 0.0d;
		for(Loan e: loans)
			sumLoan += e.getLoanAmount();
		
		this.totalAsset = this.bankBalance + sumLoan;
	}
	// reduce total asset
	public void reduceTotalAsset(double reduceAmount)
	{
		this.totalAsset -= reduceAmount;
	}	
	
	// getter
	public int getBankId()
	{
		return this.bankId;
	}
	public double getBankBalance()
	{
		return this.bankBalance;
	}
	public int numberOfLoan()
	{
		return this.numberOfLoan;
	}
	public List<Loan> getLoans()
	{
		return this.loans;
	}
	public double getTotalAsset()
	{
		return this.totalAsset;
	}
}

// This class is designed the market
public class W4Task2 {
	public static final boolean VERBOSE = false;	
	private int numberOfBanks = -1;
	private double limitAsset = -1;
	private Vector<Bank> banks = null;
	private List<Integer> unsafeBanks = null;
	private boolean isFinish = false;
	private String output = ""; 
	// constructor
	W4Task2(String filename, String delimiter) throws Exception
	{
		// initiation
		this.banks = new Vector<Bank>();
		this.unsafeBanks = new ArrayList<Integer>();
		
		// set the market situation
		this.loadMarket(filename, delimiter);
	}

	// read file and set the market situation
	public void loadMarket(String filename, String delimiter) 
					throws FileNotFoundException, IOException, Exception
	{
    	if(VERBOSE) System.out.println("----------^-----------------------------------------------------");		
        try (
        	FileReader fr = new FileReader(filename);
        	BufferedReader inputBuffer = new BufferedReader(fr);	
        )
        {
        	String line;
        	// in first line, set the number of bank
        	if ((line = inputBuffer.readLine()) != null)
        		this.numberOfBanks = W4TaskUtil.validNumberOfBank(line);
        	
        	// in second line, set the number of bank
        	if ((line = inputBuffer.readLine()) != null)
        		this.limitAsset = W4TaskUtil.validLimitAsset(line);
			
        	int bankId = 0;        	
        	String[] bankInfo;
        	// from third line, it is bank information 
        	while((line = inputBuffer.readLine()) != null)
        	{
        		// validate the information of bank
        		W4TaskUtil.validBankRow(bankId, line, delimiter);
        		if(VERBOSE) System.out.println("File line info=[" + line + "]");
        		
    			double balance  = -1.0d;
    			int numberOfloans = -1;
   			
        		bankInfo = line.split(delimiter);
        		
        		// get bank id, balance, the number of banks loaned
        		int i = 0;
        		if(VERBOSE) System.out.print("File line elements info=");        		
        		for(; i < 2; i++)
        		{
            		if(VERBOSE) System.out.print("[" + bankInfo[i] + "]");        			
        			if(i == 0) balance = new Integer(bankInfo[i]);
        			else if(i == 1) numberOfloans = new Integer(bankInfo[i]);
        		}

        		// get the loan information
        		int loanBankId = -1;
        		double loanAmount = -1.0d;
    			List<Loan> loan = new ArrayList<>();        		
        		for(int j = 0; j < numberOfloans; j++, i+=2)
        		{
            		if(VERBOSE) System.out.print("[" + bankInfo[i] + "]");        			
            		if(VERBOSE) System.out.print("[" + bankInfo[i+1] + "]");            		
        			loanBankId = new Integer(bankInfo[i]);  
        			loanAmount = new Double(bankInfo[i+1]);
        			loan.add(new Loan(loanBankId, loanAmount));
        		}
        		if(VERBOSE) System.out.println();        		
        		
        		// add a bank information to bank set
        		this.banks.add(new Bank(bankId, balance, numberOfloans, loan));
    			bankId++;
        	}
        	// check matching between the number of bank of file and actual the number of bank
        	W4TaskUtil.validNumberMatch(this.numberOfBanks, this.banks.size());
        } 
	}	
	
	// estimate market whether or not bank is unsafe state
	public void estimateMarket()
	{
		// check if the unsafe bank until checking all related banks and there exist no more unsafe banks   
		while(!this.isFinish)
		{
			isFinish = true;
			// after checking if already registering as unsafe bank,
			// if not, if total asset is less than limit asset, register it as an unsafe bank
			this.banks.stream()
					  .filter(e -> !this.unsafeBanks.contains(e.getBankId()))
			          .filter(e -> e.getTotalAsset() < this.limitAsset)
			          .forEach(e -> {
			        	  this.unsafeBanks.add(e.getBankId());
			        	  // NOTE: unsafe banks reduce the total asset of lender
			        	  this.banks.stream().forEach( i -> {
			        		for(Loan l: i.getLoans())
			        			if(l.getLoanBankId() == e.getBankId()) 
			        				i.reduceTotalAsset(l.getLoanAmount());
			        	  });

			        	  this.isFinish = false;
			          });
			
			for(Bank e: this.banks)
				if(VERBOSE) System.out.println("Estimated object: bank id" + e.getBankId() + ", total asset" + e.getTotalAsset());
		}
	}
	
	// display the information of the unsafe bank
	public void displayUnsafeBanks()
	{
    	if(VERBOSE) System.out.println("----------^-----------------------------------------------------");		
		System.out.print("Unsafe banks are ");
		this.unsafeBanks.forEach(e -> this.output += "Bank " + e + " and " );
		if(this.output != null && this.output.length() > 0)
			System.out.println(this.output.substring(0, this.output.lastIndexOf(" and ")));
		else
			System.out.print(" not exist!");
	}
    
    // test program
    public static void main(String[] args) 
    {
		try
		{
			// The text file name is passed as a command-line argument
			// check command-line argument count
			if(args != null && args.length < 2)
				throw new IllegalArgumentException(W4TaskIF.ERR12_MSG);

			W4Task2 market = new W4Task2(args[0], args[1]);
			market.estimateMarket();
			market.displayUnsafeBanks();			
		}
		catch(Workshop4Exception we)
		{
			System.out.println(we.getMessage());
		}		
		catch(IllegalArgumentException ie)
		{
			System.out.println(ie.getMessage());
		}
    	catch(FileNotFoundException fe)
    	{
    		System.out.println(W4TaskIF.ERR2_MSG);
    	}		
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
    }
}
