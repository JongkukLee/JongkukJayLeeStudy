/**********************************************
 Course:JAC444 - 4
 Last Name: Lee
 First Name: Jongkuk
 ID: 127730158
 Section: SCC
 This assignment represents my own work in accordance with
 Seneca Academic Policy.
 Signature JK Lee
 Date: 2017-12-21
**********************************************/
package ca.jay.jac444.workshop4;

import java.net.*;
import java.util.Date;
import java.io.*;

// This class is designed for client worker who do actual action between server and client
public class ClientWorker implements Runnable 
{
	private Socket client;

	public ClientWorker(Socket client){
		this.client = client;
		
		// display the connection log
		System.out.println("Connection from Socket[" + 
							"addr=" 		+ client.getInetAddress() + "," + 
							"port=" 		+ client.getPort() + "," +
							"localport=" 	+ client.getLocalPort() + "] at " + 
							new Date().toString() + "\n"
		);
	}

	// override run method which is in Runnable object
	@Override
	public void run()
	{
		String line = "";
		BufferedReader in = null;
		PrintWriter out = null;

		try
		{
			in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			out = new PrintWriter(client.getOutputStream(), true);
			
			// until finish connection
			while(line != null && line.indexOf("stop") == -1)
			{
				line = in.readLine();
				//System.out.println("Original [" + line + "]");
				
				if(line != null)
				{
					int idx = line.indexOf(W4TaskIF.DELIMITE_CHAT);
					String nick = line.substring(0, idx);
					String talk = line.substring(idx+5);
					System.out.println(nick + ": " + talk);
				}
				else
				{
					//System.out.println("something wrong!!!");
				}
			}
		}
		catch(IOException e)
		{
			System.out.println(W4TaskIF.ERR16_MSG);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if(in != null) in.close();
				if(out != null) out.close();			
			}
			catch(Exception e)
			{
				
			}
		}
	
	}
}